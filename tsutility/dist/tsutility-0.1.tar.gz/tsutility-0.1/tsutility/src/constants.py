"""
constant class
"""

class constants():

    """
    EPSILON
    """

    EPSILON = 0.0000001
