import setuptools

setuptools.setup(
    name="tsutility",
    version="0.1",
    author="Kevin Choi",
    author_email="kjchoi10@gmail.com",
    description="xyz",
    url="https://github.com/newelldatascience/tsutility/tree/master/tsutility/tsutility/src",
    packages= setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.0',
)# -*- coding: utf-8 -*-
